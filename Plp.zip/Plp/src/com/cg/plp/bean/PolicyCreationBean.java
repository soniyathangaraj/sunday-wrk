package com.cg.plp.bean;

public class PolicyCreationBean {
	private int policyNumber;
	private double policyPremium;
	private int questionId;
	private String answer1;
	private String answer2;
	private String answer3;
	private String answer4;
	private double accountNumber;
	private String quesDesc;
	private int answer1Weightage;
	private int answer2Weightage;
	private int answer3Weightage;
	private int answer4Weightage;
	private int segmentId;
	public int getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}
	public double getPolicyPremium() {
		return policyPremium;
	}
	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getAnswer2() {
		return answer2;
	}
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	public String getAnswer3() {
		return answer3;
	}
	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}
	public String getAnswer4() {
		return answer4;
	}
	public void setAnswer4(String answer4) {
		this.answer4 = answer4;
	}
	public double getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(double accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getQuesDesc() {
		return quesDesc;
	}
	public void setQuesDesc(String quesDesc) {
		this.quesDesc = quesDesc;
	}
	public int getAnswer1Weightage() {
		return answer1Weightage;
	}
	public void setAnswer1Weightage(int answer1Weightage) {
		this.answer1Weightage = answer1Weightage;
	}
	public int getAnswer2Weightage() {
		return answer2Weightage;
	}
	public void setAnswer2Weightage(int answer2Weightage) {
		this.answer2Weightage = answer2Weightage;
	}
	public int getAnswer3Weightage() {
		return answer3Weightage;
	}
	public void setAnswer3Weightage(int answer3Weightage) {
		this.answer3Weightage = answer3Weightage;
	}
	public int getAnswer4Weightage() {
		return answer4Weightage;
	}
	public void setAnswer4Weightage(int answer4Weightage) {
		this.answer4Weightage = answer4Weightage;
	}
	public int getSegmentId() {
		return segmentId;
	}
	public void setSegmentId(int segmentId) {
		this.segmentId = segmentId;
	}
	
	
}
