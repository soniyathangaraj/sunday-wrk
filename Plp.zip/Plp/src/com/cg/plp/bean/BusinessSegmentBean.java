package com.cg.plp.bean;

public class BusinessSegmentBean {

}
