package com.cg.plp.exception;

public class InsuranceException extends Exception 
{

	
	
		private static final long serialVersionUID = 726264577455921591L;

		 public InsuranceException() {
			// TODO Auto-generated constructor stub
			super(getMessage());
		}
		
	

	
}
